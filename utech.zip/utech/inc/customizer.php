<?php

/**
 * [utech_customize_register auto refresh for custom logo]
 * @param  [type] $wp_customize [array]
 * @return [type]               [array]
 */
function utech_customize_register( $wp_customize ) {
  $wp_customize->get_setting( 'custom_logo' )->transport = 'refresh';
}
add_action( 'customize_register', 'utech_customize_register' );



/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function utech_customize_preview_js() {
	wp_enqueue_script( 'utech-customizer', UTECH_ROOT_JS . '/customizer.js', array( 'customize-preview' ), UTECH_VERSION, true );
}
add_action( 'customize_preview_init', 'utech_customize_preview_js' );