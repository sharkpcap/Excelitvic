<?php 

/*-----------------------------------
    FAVICON ICON SECTION
------------------------------------*/
CSF::createSection( UTECH_OPTION_KEY,
    array(
           
        'title'  => esc_html__('Favicon Icon','utech'),
        'icon'   => 'fa fa-star',
        'fields' => array(
            array(
                'type'    => 'subheading',
                'content' => esc_html__( 'Favicon / Site Icon', 'utech' ),
            ),
            array(
                'id'      => 'favicon_icon',
                'type'    => 'media',
                'title'   => esc_html__( 'Set Favicon Icon', 'utech' ),
                'desc'    => esc_html__( 'Set the favicon icon size ( 16px x 16px ) OR ( 32px x 32px )', 'utech' ),
                'preview' => true,
                'url'     => true,
            ),
            array(
                'id'      => 'favicon_iphone',
                'type'    => 'media',
                'title'   => esc_html__( 'Set Iphone Favicon Icon', 'utech' ),
                'desc'    => esc_html__( 'Set the iphone favicon icon size ( 57px x 57px )', 'utech' ),
                'preview' => true,
                'url'     => true,
            ),
            array(
                'id'      => 'favicon_iphone_retina',
                'type'    => 'media',
                'title'   => esc_html__( 'Set Iphone Retina Favicon Icon', 'utech' ),
                'desc'    => esc_html__( 'Set the iphone retina favicon icon size ( 144px x 144px )', 'utech' ),
                'preview' => true,
                'url'     => true,
            ),
            array(
                'id'      => 'favicon_ipad',
                'type'    => 'media',
                'title'   => esc_html__( 'Set Ipad Favicon Icon', 'utech' ),
                'desc'    => esc_html__( 'Set the ipad favicon icon size ( 72px x 72px )', 'utech' ),
                'preview' => true,
                'url'     => true,
            ),
            array(
                'id'      => 'favicon_ipad_retina',
                'type'    => 'media',
                'title'   => esc_html__( 'Set Ipad Retina Favicon Icon', 'utech' ),
                'desc'    => esc_html__( 'Set the ipad retina favicon icon size ( 144px x 144px )', 'utech' ),
                'preview' => true,
                'url'     => true,
            ),
        )
    )
);
