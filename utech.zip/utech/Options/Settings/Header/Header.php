<?php 

/*-----------------------------------
    HEADER TAB SECTION
------------------------------------*/
CSF::createSection( UTECH_OPTION_KEY,
    array(
        'id'    => 'Header_Tab',
        'title' => esc_html__( 'Header', 'utech' ),
        'icon'  => 'fa fa-home',
    )
);

/*-----------------------------------
    REQUIRE OPTION FILES
------------------------------------*/
require_once( UTECH_ROOT . '/Options/Settings/Header/Topbar.php' );
require_once( UTECH_ROOT . '/Options/Settings/Header/Layout.php' );
require_once( UTECH_ROOT . '/Options/Settings/Header/Main-Menu.php' );
require_once( UTECH_ROOT . '/Options/Settings/Header/Mobile-Menu.php' );
require_once( UTECH_ROOT . '/Options/Settings/Header/Logo.php' );
require_once( UTECH_ROOT . '/Options/Settings/Header/Offcanvas.php' );