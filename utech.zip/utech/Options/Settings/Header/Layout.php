<?php

/*-----------------------------------
    HEADER LAYOUT SECTION
------------------------------------*/
CSF::createSection( UTECH_OPTION_KEY,
    array(
        'parent' => 'Header_Tab',
        'title'  => esc_html__( 'Header Layout', 'utech' ),
        'icon'   => 'fa fa-credit-card',
        'fields' => array(
            array(
                'type'    => 'subheading',
                'content' => esc_html__( 'Header Layout Style', 'utech' ),
            ),
            array(
                'id'      => 'enable_header_style',
                'type'    => 'switcher',
                'title'   => esc_html__( 'Enable Header Style', 'utech' ),
                'desc'    => esc_html__( 'If you want to enable or disable header style you can set ( YES / NO )', 'utech' ),
                'default' => false,
            ),
            array(
                'type'    => 'subheading',
                'content' => esc_html__( 'Header Layout', 'utech' ),
            ),
            array(
                'id'      => 'header_style',
                'type'    => 'image_select',
                'title'   => esc_html__( 'Header Style', 'utech' ),
                'desc'    => esc_html__( 'Select the header style which you want to show on your website.', 'utech' ),
                'options' => utech_header_layout( array( 'header-1', 'header-2' ) ),
                'default' => UTECH_HEADER_LAYOUT,
            ),
        )
    )
);