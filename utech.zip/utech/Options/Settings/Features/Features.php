<?php

/*-----------------------------------
EASY DIGITAL DOWNLOAD SECTION
------------------------------------*/
if ( !class_exists( 'Easy_Digital_Downloads' ) ) {
    return;
}

/*-----------------------------------
    FEATURES TAB SECTION
------------------------------------*/
CSF::createSection( UTECH_OPTION_KEY,
    array(
        'id'     => 'Features_Tab',
        'title'  => esc_html__( 'Features & Frameworks', 'utech' ),
        'icon'   => 'fa fa-sitemap',
    )
);

/*-----------------------------------
    REQUIRE OPTION FILES
------------------------------------*/
require_once( UTECH_ROOT . '/Options/Settings/Features/EDD.php' );