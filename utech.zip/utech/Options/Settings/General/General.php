<?php 

/*-----------------------------------
    GENARAL TAB SECTION
------------------------------------*/
CSF::createSection( UTECH_OPTION_KEY, 
    array(
        'id'     =>'General_Tab',
        'icon'   => 'fa fa-cogs',
        'title'  => esc_html__( 'General','utech')
    )
);

/*-----------------------------------
    REQUIRE OPTION FILES
------------------------------------*/
require_once( UTECH_ROOT . '/Options/Settings/General/Typography.php' );
require_once( UTECH_ROOT . '/Options/Settings/General/Banner.php' );
require_once( UTECH_ROOT . '/Options/Settings/General/Global-Design.php' );