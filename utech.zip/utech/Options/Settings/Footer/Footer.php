<?php 
        
/*-----------------------------------
    FOOTER TAB SECTION
------------------------------------*/
CSF::createSection( UTECH_OPTION_KEY,
    array(
        'id'    => 'Footer_Tab',
        'title' => esc_html__( 'Footer', 'utech' ),
        'icon'  => 'fa fa-credit-card',
    )
);

/*-----------------------------------
    REQUIRE OPTION FILES
------------------------------------*/
require_once( UTECH_ROOT . '/Options/Settings/Footer/Footer-General.php' );
require_once( UTECH_ROOT . '/Options/Settings/Footer/Footer-Top.php' );
require_once( UTECH_ROOT . '/Options/Settings/Footer/Footer-Bottom.php' );
require_once( UTECH_ROOT . '/Options/Settings/Footer/Copyright.php' );