<?php

/*-----------------------------------
    CUSTOM CSS SECTION
------------------------------------*/
CSF::createSection( UTECH_META_KEY,
	array(
		'title'  => esc_html__( 'Custom CSS', 'utech' ),
        'parent' => 'Page_Meta_Tab',
		'fields' => array(
			array(
				'type'    => 'subheading',
				'content' => esc_html__( 'Page Custom Css', 'utech' ),
			),
            array(
                'id'       => 'page_cs_css',
                'type'     => 'code_editor',
                'desc'     => esc_html__( 'Write custom css here with css selector. this css will be applied in this page.', 'utech' ),
                'settings' => array(
                    'mode'        => 'css',
                    'theme'       => 'dracula',
                    'tabSize'     => 4,
                    'smartIndent' => true,
                    'autocorrect' => true,
                ),
                'sanitize' => false,
            ),
		)
	)
);