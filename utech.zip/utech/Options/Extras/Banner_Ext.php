<?php

CSF::createSection( UTECH_OPTION_KEY,
    array(
        'icon'   => 'fa fa-book',
        'title'  => 'Banner',
        'fields' => array(

            array(
                'type'    => 'subheading',
                'content' => esc_html__( 'Blog Banner', 'utech' ),
            ),
            array(
                'id'      => 'blog_banner_show',
                'type'    => 'switcher',
                'title'   => esc_html__( 'Blog Banner', 'utech' ),
                'default' => true,
            ),
            array(
                'id'      => 'blog_show_breadcrumb',
                'type'    => 'switcher',
                'title'   => esc_html__( 'Blog Banner', 'utech' ),
                'default' => true,
            ),
            array(
                'id'      => 'banner_blog_title',
                'type'    => 'switcher',
                'title'   => esc_html__( 'Blog Banner', 'utech' ),
                'default' => true,
            ),
            array(
                'id'      => 'banner_blog_image',
                'type'    => 'upload',
                'title'   => esc_html__( 'Upload Background', 'utech' ),
                'desc'    => esc_html__( 'Upload main Image width 1200px and height 400px.', 'utech' ),
                'default' => '',
            ),
            array(
                'type'    => 'subheading',
                'content' => esc_html__( 'Page Banner', 'utech' ),
            ),
            array(
                'id'      => 'page_banner_show',
                'type'    => 'switcher',
                'title'   => esc_html__( 'Page Banner', 'utech' ),
                'default' => true,
            ),
            array(
                'id'      => 'page_show_breadcrumb',
                'type'    => 'switcher',
                'title'   => esc_html__( 'Page Banner', 'utech' ),
                'default' => true,
            ),
            array(
                'id'      => 'banner_page_title',
                'type'    => 'switcher',
                'title'   => esc_html__( 'Page Banner', 'utech' ),
                'default' => true,
            ),
            array(
                'id'      => 'banner_page_image',
                'type'    => 'upload',
                'title'   => esc_html__( 'Upload Background', 'utech' ),
                'desc'    => esc_html__( 'Upload main Image width 1200px and height 400px.', 'utech' ),
                'default' => '',
            ),
            array(
                'id'      => 'layout_extras',
                'type'    => 'image_select',
                'title'   => esc_html__( 'Header Style', 'utech' ),
                'desc'    => esc_html__( 'Select the header style which you want to show on your website.', 'utech' ),
                'options' => array(
                    'header-1'  => UTECH_ROOT_IMAGE . '/header/header_1.png',
                    'header-2'  => UTECH_ROOT_IMAGE . '/header/header_2.png',
                    'header-3'  => UTECH_ROOT_IMAGE . '/header/header_3.png',
                    'header-4'  => UTECH_ROOT_IMAGE . '/header/header_4.png',
                    'header-5'  => UTECH_ROOT_IMAGE . '/header/header_5.png',
                    'header-6'  => UTECH_ROOT_IMAGE . '/header/header_6.png',
                    'header-7'  => UTECH_ROOT_IMAGE . '/header/header_7.png',
                    'header-8'  => UTECH_ROOT_IMAGE . '/header/header_7.png',
                    'header-9'  => UTECH_ROOT_IMAGE . '/header/header_1.png',
                    'header-10' => UTECH_ROOT_IMAGE . '/header/header_10.jpg',
                    'header-11' => UTECH_ROOT_IMAGE . '/header/header_11.jpg',
                ),
                'default' => 'header-1',
            ),
        ),
    )
);