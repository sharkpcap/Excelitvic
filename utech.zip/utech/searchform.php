<?php
/**
 * Template for displaying search forms.
 *
 * @package uTech
 * @since 1.0.0
 *
 */
?>

<?php
add_filter('get_search_form', function ($form) {
    $form = '<form class="search-form" action="' . esc_url(home_url('/')) . '">
                <input  name="s" placeholder="' . esc_attr__('Search...', 'utech') . '" type="search">
                <button type="submit"><i class="ti-search"></i></button>
            </form>';
    return $form;
});