<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package uTech
 * @since 1.0.0
 * 
 */

get_header();

$page_meta_array = utech_metabox_value('_utech_page_metabox');
$enable_banner   = isset( $page_meta_array['enable_banner'] ) ? $page_meta_array['enable_banner'] : true;

?>
	<?php 
		if ( $enable_banner == true ) {
			if (function_exists('utech_title')) {
			    utech_title();
			}
		}
	?>
    <div class="content-area section-padding">
        <div class="container">
            <div class="row">
				<div class="col-md-12">
					<?php 
						woocommerce_content();
					?>					
				</div>
			</div>
		</div>
	</div>
<?php
get_footer();