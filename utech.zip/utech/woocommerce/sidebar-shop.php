<?php
	if ( !is_active_sidebar( 'shop-sidebar' ) ){
		return;
	}
?>
<div class="col-md-4 col-lg-4 col-sm-12 product__widgets__wrap">
	<div class="widget-area">
		<?php dynamic_sidebar( 'shop-sidebar' ); ?>
	</div>
</div>