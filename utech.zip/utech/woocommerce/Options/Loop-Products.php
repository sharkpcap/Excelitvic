<?php

/*-----------------------------------
    SINGLE PRODUCT PAGE
------------------------------------*/
CSF::createSection( UTECH_OPTION_KEY,
    array(
        'parent' => 'WooCommerce_Tab',
        'title'  => esc_html__( 'Loop Products', 'utech' ),
        'icon'   => 'fa fa-shopping-bag',
        'fields' => array(

            array(
                'type'    => 'subheading',
                'content' => esc_html__( 'Loop Product Item Settings', 'utech' ),
            ),

            array(
                'id'      => 'enable_percentage_bedge',
                'type'    => 'switcher',
                'title'   => esc_html__( 'Enable Percentage Bedge?', 'utech' ),
                'desc'    => esc_html__( 'You can set percentage bedge in product. just set ( YES / NO ) for OFF or ON.', 'utech' ),
                'default' => true,
            ),

            array(
                'id'      => 'enable_product_group_buttons',
                'type'    => 'switcher',
                'title'   => esc_html__( 'Enable Add To Cart Group Buttons?', 'utech' ),
                'desc'    => esc_html__( 'If you want to enable product group buttons then you can set ( YES / NO )', 'utech' ),
                'default' => true,
            ),

            array(
                'id'      => 'enable_add_to_cart_default_button',
                'type'    => 'switcher',
                'title'   => esc_html__( 'Enable Add To Cart Default Button?', 'utech' ),
                'desc'    => esc_html__( 'If you want to enable add to cart default button then you can set ( YES / NO )', 'utech' ),
                'default' => false,
            ),
            array(
                'id'      => 'change_add_to_cart_button_text',
                'type'    => 'switcher',
                'title'   => esc_html__( 'Change Add To Cart Button Text?', 'utech' ),
                'desc'    => esc_html__( 'If you want to add to cart button text you can set ( YES / NO )', 'utech' ),
                'default' => false,
                'dependency' => array( 'enable_add_to_cart_default_button', '==', 'true' ),
            ),
            array(
                'id'         => 'custom_add_to_cart_button_text',
                'type'       => 'text',
                'title'      => esc_html__( 'Add To Cart Button Text', 'utech' ),
                'desc'       => esc_html__( 'Set the custom add to cart button text.', 'utech' ),
                'default'    => 'Buy now',
                'dependency' => array( 'change_add_to_cart_button_text|enable_add_to_cart_default_button', '==|==', 'true|true' ),
            ),

            array(
                'id'      => 'change_variable_product_custom_cart_button_text',
                'type'    => 'switcher',
                'title'   => esc_html__( 'Change Variable Product Add To Cart Button Text?', 'utech' ),
                'desc'    => esc_html__( 'If you want to add to cart button text you can set ( YES / NO )', 'utech' ),
                'default' => false,
            ),
            array(
                'id'         => 'variable_product_custom_cart_button_text',
                'type'       => 'text',
                'title'      => esc_html__( 'Variable Product Add To Cart Button Text', 'utech' ),
                'desc'       => esc_html__( 'Set the custom add to cart button text for variable product.', 'utech' ),
                'default'    => 'Buy now',
                'dependency' => array( 'change_variable_product_custom_cart_button_text', '==', 'true' ),
            ),

        ),
    )
);