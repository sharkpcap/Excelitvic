<?php

if ( !class_exists( 'WooCommerce' ) ) {
    return;
}

/*-----------------------------------
    WOOCOMMERCE TAB SECTION
------------------------------------*/
CSF::createSection( UTECH_OPTION_KEY,
    array(
        'id'     => 'WooCommerce_Tab',
        'title'  => esc_html__( 'WooCommerce', 'utech' ),
        'icon'   => 'fa fa-store',
    )
);

/*-----------------------------------
    REQUIRE OPTION FILES
------------------------------------*/
require_once( UTECH_ROOT . '/woocommerce/Options/Shop-Page.php' );
require_once( UTECH_ROOT . '/woocommerce/Options/Checkout-Page.php' );
require_once( UTECH_ROOT . '/woocommerce/Options/Loop-Products.php' );
require_once( UTECH_ROOT . '/woocommerce/Options/Single-Product.php' );
require_once( UTECH_ROOT . '/woocommerce/Options/Related-Product.php' );
require_once( UTECH_ROOT . '/woocommerce/Options/Upsells-Product.php' );
require_once( UTECH_ROOT . '/woocommerce/Options/Miscellaneous.php' );