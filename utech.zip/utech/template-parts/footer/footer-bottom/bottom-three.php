<?php
	$enable_footer_social = utech_get_option( 'enable_footer_social', false );
?>
<div class="row width100p">
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-6">
				<div class="footer-logo">
					<?php 
						utech_default_logo();
					?>
				</div>
			</div>
			<div class="col-md-6">
				<?php
					if ( has_nav_menu( 'footer_menu' ) ) {
						wp_nav_menu( array(
							'theme_location'  => 'footer_menu',
							'menu'            => '',
							'container'       => 'div',
							'container_class' => 'footer_menu',
							'container_id'    => 'footer_menu',
							'depth'           => 1,
						));
					}
				?>
			</div>
		</div>
	</div>
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-6">
				<div class="footer-copyright sm-center xs-center">
					<?php utech_copyright(); ?>
				</div>
			</div>
			<?php if( $enable_footer_social == true ): ?>
				<div class="col-md-6">
					<div class="footer-social-bookmark text-right xs-center sm-center">
						<?php utech_social_links(); ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>