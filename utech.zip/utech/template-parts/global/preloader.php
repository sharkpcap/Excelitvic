<?php 
    $preloader_style  = utech_get_option( 'preloader_style', $default = 'style_6' );
    $custom_preloader = utech_get_option( 'add_preloader_image' );
?>
<?php if( '1' == utech_get_option( 'enable_custom_preloader' ) && !empty( $custom_preloader['url'] ) ) : ?>
    <?php if( $custom_preloader['url'] ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( $custom_preloader['url'] ); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php endif; ?>
<?php else: ?>
    <?php if( 'style_3' == $preloader_style ) : ?>
        <div class="preeloader">
            <div class="preloader-spinner"></div>
        </div>
    <?php elseif( 'style_4' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/loader_horizontal.gif'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_5' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/loader_spinner.gif'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_6' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/loader_spinner.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_7' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/loader_square_circle.gif'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_8' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/loader_wave.gif'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_9' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/loeader_square.gif'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_10' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/wave_preloader.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_11' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/ajax_loader.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_12' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/audio.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_13' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/ball_triangle.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_14' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/bars.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_15' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/circle_pulse_rings.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_16' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/circle_tail_spin.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_17' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/circles.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_18' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/flip_circle.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_19' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/grid.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_20' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/heart.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_21' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/hearts_group.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_22' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/horizontal_loader_2.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_23' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/road_cross.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_24' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/round_circle.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_25' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/round_pulse.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_26' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/simple_spainer.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_27' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/spinner.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_28' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/spinning_circles.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php elseif( 'style_29' == $preloader_style ) : ?>
        <div class="preeloader">
            <img src="<?php echo esc_url( UTECH_ROOT_IMAGE .'/loader/three_dots.svg'); ?>" alt="<?php echo esc_attr__( 'preloader', 'utech' ); ?>">
        </div>
    <?php endif; ?>
<?php endif; ?>