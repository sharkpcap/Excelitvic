<?php
    $page_meta_array        = utech_metabox_value( '_utech_page_metabox' );
    $enable_header_styling = isset( $page_meta_array['enable_header_styling'] ) ? $page_meta_array['enable_header_styling'] : false;
    if ( is_page() && $enable_header_styling == true ) {
        if ( !empty( $page_meta_array['menu_width'] ) ) {
            $menu_width = $page_meta_array['menu_width'];
        }
    } else {
        $menu_width = utech_get_option( 'menu_width', 'container container__full' );
    }
    
?>
<?php if ( '1' == utech_get_option( 'enable_topbar', false ) ): ?>
<!-- TOP BAR -->
<div class="top-bar d-none d-lg-block">
    <div class="<?php echo esc_attr( $menu_width ); ?>">
        <div class="row flex-v-center">
            <div class="col-md-6 col-xs-12 col-sm-8">
                <div class="top-left-contact">
                    <?php if ( !empty( utech_get_option( 'phone_number' ) ) ): ?>
                    <div class="topbar-single-contact">
                        <div class="topbar-contact-icon"><i class="ti ti-headphone-alt"></i></div>
                        <h4><?php echo esc_html__( 'Call Us', 'utech' ) ?></h4>
                        <p><?php echo esc_html( utech_get_option( 'phone_number' ) ); ?></p>
                    </div>
                    <?php endif;?>
                    <?php if ( !empty( utech_get_option( 'email_address' ) ) ): ?>
                    <div class="topbar-single-contact">
                        <div class="topbar-contact-icon"><i class="ti ti-email"></i></div>
                        <h4><?php echo esc_html__( 'Mail To', 'utech' ) ?></h4>
                        <p><?php echo esc_html( utech_get_option( 'email_address' ) ); ?></p>
                    </div>
                    <?php endif;?>
                </div>
            </div>
            <div class="col-md-2 col-xs-12">
                <div class="navbar-header topbar-logo">
                    <?php utech_logo_with_sticky();?>
                </div>
            </div>
            <div class="col-md-6 col-xs-12 col-sm-4">
                <div class="header-action d-none d-lg-flex">

                    <?php get_template_part( 'template-parts/header/actions/action', 'cart' );?>
                    <?php get_template_part( 'template-parts/header/actions/action', 'offcanvas' );?>
                    <?php get_template_part( 'template-parts/header/actions/action', 'search' );?>
                    <?php get_template_part( 'template-parts/header/actions/action', 'button' );?>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- TOP BAR END -->
<?php endif;?>