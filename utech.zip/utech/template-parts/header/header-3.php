<?php
	/*-------------------------------
	    MAIN MENU
	--------------------------------*/
	if ( !function_exists('utech_menu')) {
		function utech_menu(){
			/*-----------------------
				PAGE META DATA
			-------------------------*/
			$page_meta              = utech_metabox_value('_utech_page_metabox');
			$enable_header_styling = isset( $page_meta['enable_header_styling'] ) ? $page_meta['enable_header_styling'] : false;

	        if ( is_page() && $enable_header_styling == true ) {
	        	if ( !empty($page_meta['menu_width']) ) {
	        		$menu_width = $page_meta['menu_width'];
	        	}
	        }else{
	        	$menu_width = utech_get_option( 'menu_width', 'container container__full' );
	        }
	    ?>
	    <div class="header-top-area">
	    	<?php get_template_part( 'template-parts/header/search/search', utech_get_option( 'header_search_layout', 'one' ) ); ?>
	    	<?php get_template_part( 'template-parts/header/topbar/topbar', utech_get_option( 'header_topbar_layout', 'one' ) ); ?>      
	        
	        <!-- MAINMENU AREA -->
	        <div class="mainmenu-area" id="mainmenu-area">
	            <!-- <div class="mainmenu-area-bg"></div> -->
	            <nav class="navbar">
	                <div class="<?php echo esc_attr( $menu_width ); ?>">
	                	<div class="menu-bg-and-layer"></div>
	                    <div class="row">
	                        <div class="col-md-12 flex-v-center">
	                            <div class="navbar-header">
	                                <?php utech_logo_with_sticky(); ?>
	                            </div>
	                            <svg class="ham hamRotate ham8" viewBox="0 0 100 100" width="60">
	                                <path class="line top" d="m 30,33 h 40 c 3.722839,0 7.5,3.126468 7.5,8.578427 0,5.451959 -2.727029,8.421573 -7.5,8.421573 h -20" />
	                                <path class="line middle" d="m 30,50 h 40" />
	                                <path class="line bottom" d="m 70,67 h -40 c 0,0 -7.5,-0.802118 -7.5,-8.365747 0,-7.563629 7.5,-8.634253 7.5,-8.634253 h 20" />
	                            </svg>
	                            <?php
	                                wp_nav_menu( array(
										'theme_location'  => 'mainmenu',
										'menu_id'         => 'nav',
										'menu'            => 'ul',
										'menu_class'      => 'nav navbar-nav pull-right',
										'container'       => 'div',
										'container_class' => 'stellarnav',
										'container_id'    => 'main-nav',
										'fallback_cb'     => 'utech_menu_default_fallback',
										'walker'          => new utech_Nav_Menu_Walker(),
	                                ) );
	                            ?>

	                            <?php if( '1' == utech_get_option( 'enable_header_actions', false ) ) : ?>

	                            <div class="header-action d-none d-lg-flex">

									<?php get_template_part( 'template-parts/header/actions/action', 'search' ); ?>
									<?php get_template_part( 'template-parts/header/actions/action', 'cart' ); ?>
									<?php get_template_part( 'template-parts/header/actions/action', 'offcanvas' ); ?>
	                            	
	                            </div>

	                        	<?php endif; ?>
	                        </div>
	                    </div>
	                </div>
	            </nav>
	        </div>
	        <!-- END MAINMENU AREA END -->

			<?php get_template_part( 'template-parts/header/content/content', 'offcanvas' ); ?>
	    	
	    </div>
	    <?php
		}
	}

    if (function_exists('utech_menu')) {
        utech_menu();
    }
?>