<div class="currency__switcher flex">
    <div class="currency__switcher__text"><?php esc_html_e( 'Currency', 'utech' ); ?> | </div>
    <div class="currency__switcher__menu">
        <select name="currency__switcher" id="currency__switcher">
            <option value="usd"><?php esc_html_e( 'USD', 'utech' ); ?></option>
            <option value="gbp"><?php esc_html_e( 'GBP', 'utech' ); ?></option>
            <option value="eur"><?php esc_html_e( 'EUR', 'utech' ); ?></option>
            <option value="aud"><?php esc_html_e( 'AUD', 'utech' ); ?></option>
            <option value="cad"><?php esc_html_e( 'CAD', 'utech' ); ?></option>
        </select>
    </div>
</div>