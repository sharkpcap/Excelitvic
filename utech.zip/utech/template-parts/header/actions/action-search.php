<?php if( '1' == utech_get_option( 'enable_search', false ) ) : ?>
	<a href="#" class="search-button"><i class="ti ti-search"></i></a>
<?php endif; ?>