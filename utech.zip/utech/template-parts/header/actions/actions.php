<?php get_template_part( 'template-parts/header/actions/action', 'cart' ); ?>
<?php get_template_part( 'template-parts/header/actions/action', 'button' ); ?>
<?php get_template_part( 'template-parts/header/actions/action', 'search' ); ?>
<?php get_template_part( 'template-parts/header/actions/action', 'language' ); ?>
<?php get_template_part( 'template-parts/header/actions/action', 'offcanvas' ); ?>
<?php get_template_part( 'template-parts/header/actions/action', 'promomenu' ); ?>
<?php get_template_part( 'template-parts/header/actions/action', 'usermenu' ); ?>