<?php if( '1' == utech_get_option( 'enable_offcanvas', false ) ): ?>
	<a href="#" class="menu-button"><i class="ti ti-menu"></i></a>
<?php endif; ?>