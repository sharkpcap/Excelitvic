<?php if( '1' == utech_get_option( 'enable_cart_button', false ) && class_exists( 'Easy_Digital_Downloads' ) ) : ?>
	<?php get_template_part( 'edd/cart/header-cart' ); ?>
<?php endif; ?>

<?php if( '1' == utech_get_option( 'enable_cart_button', false ) && class_exists( 'WooCommerce' ) ) : ?>

	<?php if( '1' == utech_get_option( 'enable_mini_cart', false ) ) : ?>
		<?php utech_woocommerce_header_cart();?>
	<?php else : ?>
		<a href="#" class="cart-contents cart-button"><i class="ti-shopping-cart"></i></a>
	<?php endif; ?>
	
<?php endif; ?>