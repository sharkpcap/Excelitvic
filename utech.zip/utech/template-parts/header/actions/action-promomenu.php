<?php
	if ( true == utech_get_option('enable_promo_menu',false) ) {
		if ( has_nav_menu( 'promo_menu' ) ) {
		    wp_nav_menu( array(
				'theme_location'  => 'promo_menu',
				'menu_id'         => 'paromo-menu',
				'menu'            => 'ul',
				'menu_class'      => 'nav navbar-nav pull-right',
				'container'       => 'div',
				'container_class' => 'promotion__menu visible-lg',
				'container_id'    => 'promotionl-nav',
				'depth'           => 1,
		    ) );
		}
	}
?>