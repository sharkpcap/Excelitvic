<?php if( '1' == utech_get_option( 'enable_search', false ) ) : ?>
<div class="search-form-control">
	<div id="search-form-<?php echo esc_attr( utech_get_option( 'header_search_layout', 'one' ) )?>" class="search-form-<?php echo esc_attr( utech_get_option( 'header_search_layout', 'one' ) )?>">					
		<?php utech_search_form(false,false); ?>
	</div>
    <div class="search-control-bg"></div>
	<button class="search-mode-close"><i class="ti ti-close"></i></button>
</div>
<?php endif; ?>