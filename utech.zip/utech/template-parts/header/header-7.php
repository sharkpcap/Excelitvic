<?php
	/*-------------------------------
	    MAIN MENU
	--------------------------------*/
	if ( !function_exists('utech_menu')) {
		function utech_menu(){
			/*-----------------------
				PAGE META DATA
			-------------------------*/
			$page_meta              = utech_metabox_value('_utech_page_metabox');
			$enable_header_styling = isset( $page_meta['enable_header_styling'] ) ? $page_meta['enable_header_styling'] : false;

	        if ( is_page() && $enable_header_styling == true ) {
	        	if ( !empty($page_meta['menu_width']) ) {
	        		$menu_width = $page_meta['menu_width'];
	        	}
	        }else{
	        	$menu_width = utech_get_option( 'menu_width', 'container container__full' );
	        }
	    ?>
	    <div class="header-top-area">
	    	<?php get_template_part( 'template-parts/header/search/search', utech_get_option( 'header_search_layout', 'one' ) ); ?>
	        
	        <!-- MAINMENU AREA -->
	        <div class="mainmenu-area" id="mainmenu-area">
	            <div class="mainmenu-area-bg"></div>
	            <nav class="navbar">
	                <div class="<?php echo esc_attr( $menu_width ); ?>">
	                    <div class="row">
	                        <div class="col-md-12 flex-v-center">
								
								<div class="navbar-header">
	                                <?php utech_logo_with_sticky(); ?>
	                            </div>

								<div class="expanding__nav__social__action hidden-xs hidden-sm hidden-md">
									<?php utech_social_links(); ?>
									<?php if( !empty( utech_get_option( 'phone_number' ) ) ): ?>
		                            	<div class="contact__address">
		                            		<div class="contact__address__icon"><i class="ti ti-headphone-alt"></i></div>
		                            		<span class="contact__text"><?php echo esc_html__( 'Call Now', 'utech' ); ?></span>
		                            		<span class="contact__phone"><?php echo esc_html( utech_get_option( 'phone_number' ) ); ?></span>
		                            	</div>
		                            <?php endif; ?>
								</div>

								<svg class="ham hamRotate ham8" viewBox="0 0 100 100" width="60">
	                                <path class="line top" d="m 30,33 h 40 c 3.722839,0 7.5,3.126468 7.5,8.578427 0,5.451959 -2.727029,8.421573 -7.5,8.421573 h -20" />
	                                <path class="line middle" d="m 30,50 h 40" />
	                                <path class="line bottom" d="m 70,67 h -40 c 0,0 -7.5,-0.802118 -7.5,-8.365747 0,-7.563629 7.5,-8.634253 7.5,-8.634253 h 20" />
	                            </svg>

								<?php
	                                wp_nav_menu( array(
										'theme_location'  => 'mainmenu',
										'menu_id'         => 'nav',
										'menu'            => 'ul',
										'menu_class'      => 'nav navbar-nav pull-right expanding__main__menu',
										'container'       => 'div',
										'container_class' => 'stellarnav',
										'container_id'    => 'main-nav',
										'fallback_cb'     => 'utech_menu_default_fallback',
										'walker'          => new utech_Nav_Menu_Walker(),
	                                ) );
	                            ?>

	                            <div class="colse__expanding__nav__toggle">
	                            	<i class="beicon-multiply"></i>
	                            </div>

	                            <div class="center__fixed__logo">
	                            	<div class="center__logo__toggle">
	                                	<?php utech_logo_with_sticky(); ?>
	                            	</div>
	                                <div class="expanding__nav__toggle">
	                                	<img src="<?php echo UTECH_ROOT_IMAGE . '/menu__lines.png'; ?>" alt="<?php bloginfo( 'title' ); ?>">
	                                </div>
	                            </div>

	                            <?php if( '1' == utech_get_option( 'enable_header_actions', false ) ) : ?>  
	                            <div class="header-action d-none d-lg-flex expanding__nav___action">

									<?php get_template_part( 'template-parts/header/actions/action', 'button' ); ?>
									<?php get_template_part( 'template-parts/header/actions/action', 'search' ); ?>

	                            </div>
	                        	<?php endif; ?>

	                        </div>
	                    </div>
	                </div>
	            </nav>
	        </div>
	        <!-- END MAINMENU AREA END -->
	    </div>
	    <?php
		}
	}

    if (function_exists('utech_menu')) {
        utech_menu();
    }
?>