<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * Template Name: Composer
 * @package uTech
 * @since 1.0.0
 */
get_header();

$page_meta_array = utech_metabox_value('_utech_page_metabox');
$enable_banner   = isset( $page_meta_array['enable_banner'] ) ? $page_meta_array['enable_banner'] : true;

?>
	<?php 
		if ( is_page_template() ) {
			if ( $enable_banner == true ) {
				utech_title();
			}
		}
	?>

    <div class="content-area clearfix">
		<?php
			while ( have_posts() ) : the_post();

				the_content();

			endwhile;
		?>
	</div>
	
<?php
get_footer();