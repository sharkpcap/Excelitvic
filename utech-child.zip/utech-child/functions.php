<?php 
    add_action( 'wp_enqueue_scripts', 'utech_child_enqueue_styles' , 100 );
    function utech_child_enqueue_styles() {
        wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' ); 
    } 
?>